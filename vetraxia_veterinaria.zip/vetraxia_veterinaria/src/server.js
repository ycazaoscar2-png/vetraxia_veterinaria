require('dotenv').config();

const express = require('express');
const path = require('path');
const fs = require('fs');
const bcrypt = require('bcryptjs');
const db = require('./db');

function validarConfiguracion() {
  const obligatorias = ['DATABASE_URL', 'JWT_SECRET', 'ADMIN_EMAIL', 'ADMIN_PASSWORD'];
  const faltantes = obligatorias.filter(nombre => !process.env[nombre] || !process.env[nombre].trim());
  if (faltantes.length) {
    throw new Error(`Faltan variables de entorno obligatorias: ${faltantes.join(', ')}. Configura el archivo .env o las variables del servicio de alojamiento.`);
  }
  if (process.env.JWT_SECRET.length < 32) {
    throw new Error('JWT_SECRET debe tener al menos 32 caracteres. Genera una clave aleatoria y privada.');
  }
  if (process.env.ADMIN_PASSWORD.length < 12) {
    throw new Error('ADMIN_PASSWORD debe tener al menos 12 caracteres. Configura una contraseña nueva y segura.');
  }
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(process.env.ADMIN_EMAIL)) {
    throw new Error('ADMIN_EMAIL no tiene un formato de correo válido.');
  }
  if (!db.urlValida || !/^postgres(?:ql)?:\/\//i.test(db.urlValida)) {
    throw new Error('DATABASE_URL no contiene una URL válida de PostgreSQL.');
  }
}

const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, '..', 'public')));

app.use('/api/auth', require('./routes/auth'));
app.use('/api/servicios', require('./routes/servicios'));
app.use('/api/mascotas', require('./routes/mascotas'));
app.use('/api/horarios', require('./routes/horarios'));
app.use('/api/citas', require('./routes/citas'));
app.get('/salud', (_req, res) => res.json({ ok: true }));

// nombre, duración en minutos, precio
const SERVICIOS_BASE = [
  ['Consulta general', 30, 15],
  ['Vacunación', 30, 12],
  ['Desparasitación', 30, 8],
  ['Baño y corte', 60, 20],
  ['Cirugía menor', 90, 60]
];

async function crearAdministrador() {
  const email = process.env.ADMIN_EMAIL.trim().toLowerCase();
  const hash = await bcrypt.hash(process.env.ADMIN_PASSWORD, 12);
  const existente = await db.query('SELECT id FROM usuarios WHERE lower(email)=lower($1) AND rol=\'admin\'', [email]);
  if (existente.rowCount) {
    // Sincroniza la contraseña con el secreto configurado en el entorno.
    await db.query('UPDATE usuarios SET password_hash=$1 WHERE id=$2', [hash, existente.rows[0].id]);
    return;
  }
  await db.query(
    "INSERT INTO usuarios(nombre,email,password_hash,rol) VALUES('Administrador',$1,$2,'admin')",
    [email, hash]
  );
}

async function crearServiciosBase() {
  for (const [nombre, duracion, precio] of SERVICIOS_BASE) {
    await db.query(
      'INSERT INTO servicios(nombre,duracion_min,precio) SELECT $1::text,$2::int,$3::numeric WHERE NOT EXISTS (SELECT 1 FROM servicios WHERE nombre=$1::text)',
      [nombre, duracion, precio]
    );
  }
}

async function iniciar() {
  validarConfiguracion();
  await db.query(fs.readFileSync(path.join(__dirname, '..', 'db', 'schema.sql'), 'utf8'));
  await crearAdministrador();
  await crearServiciosBase();

  const puerto = process.env.PORT || 3000;
  app.listen(puerto, () => console.log(`VETRAXIA funcionando en el puerto ${puerto}`));
}

iniciar().catch(error => {
  console.error(`\nNo se pudo iniciar VETRAXIA: ${error.message}`);
  console.error('Comprueba las variables de entorno. No compartas el contenido de .env ni publiques tus credenciales.\n');
  process.exit(1);
});

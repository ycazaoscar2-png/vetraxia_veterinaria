// Asistente local para crear .env sin mostrar contraseñas en pantalla.
const readline = require('readline');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const archivoEnv = path.join(__dirname, '..', '.env');
const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
const salidaOriginal = rl._writeToOutput.bind(rl);
rl._writeToOutput = texto => {
  if (!rl.salidaOculta) salidaOriginal(texto);
};

function pregunta(mensaje) {
  return new Promise(resolve => rl.question(mensaje, respuesta => resolve(respuesta.trim())));
}

function preguntaOculta(mensaje) {
  return new Promise(resolve => {
    rl.output.write(mensaje);
    rl.salidaOculta = true;
    rl.question('', respuesta => {
      rl.salidaOculta = false;
      rl.output.write('\n');
      resolve(respuesta.trim());
    });
  });
}

async function iniciar() {
  console.log('\n=== Configuración segura de VETRAXIA ===');
  if (fs.existsSync(archivoEnv)) {
    const reemplazar = (await pregunta('Ya existe .env. ¿Deseas reemplazarlo? (s/N): ')).toLowerCase();
    if (reemplazar !== 's') {
      console.log('No se modificó el archivo .env.');
      return;
    }
  }

  console.log('\nEn Neon copia la URL completa de conexión (postgresql://...).');
  const databaseUrl = await preguntaOculta('URL completa de Neon (entrada oculta): ');
  if (!/^postgres(?:ql)?:\/\/\S+$/i.test(databaseUrl)) {
    throw new Error('La URL de PostgreSQL no tiene un formato válido.');
  }

  const adminEmail = (await pregunta('Correo del administrador: ')).toLowerCase();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(adminEmail)) {
    throw new Error('El correo del administrador no es válido.');
  }
  const adminPassword = await preguntaOculta('Contraseña nueva del administrador (mínimo 12 caracteres): ');
  if (adminPassword.length < 12) throw new Error('La contraseña debe tener al menos 12 caracteres.');
  const confirmar = await preguntaOculta('Repite la contraseña: ');
  if (adminPassword !== confirmar) throw new Error('Las contraseñas no coinciden.');

  const jwtSecret = crypto.randomBytes(48).toString('hex');
  const contenido = [
    `DATABASE_URL=${databaseUrl}`,
    'PORT=3000',
    'DB_SSL=true',
    `JWT_SECRET=${jwtSecret}`,
    `ADMIN_EMAIL=${adminEmail}`,
    `ADMIN_PASSWORD=${adminPassword}`,
    ''
  ].join('\n');
  fs.writeFileSync(archivoEnv, contenido, { mode: 0o600 });
  console.log('\nArchivo .env creado correctamente. La clave JWT se generó automáticamente.');
  console.log('No compartas este archivo ni lo subas a GitHub.');
}

iniciar()
  .catch(error => {
    console.error(`\nNo se pudo crear la configuración: ${error.message}`);
    process.exitCode = 1;
  })
  .finally(() => rl.close());

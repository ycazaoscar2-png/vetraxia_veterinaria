# VETRAXIA

Sistema web de gestión veterinaria para administrar clientes, mascotas, servicios, horarios y citas. Desarrollado con Node.js, Express y PostgreSQL (Neon). Incluye roles de administrador y cliente.

## Requisitos
- Node.js 18 o superior.
- Una base de datos PostgreSQL (por ejemplo, Neon).

## Configuración local
1. Instala las dependencias: `npm install`.
2. Ejecuta `node scripts/configurar.js` y sigue las indicaciones. El asistente solicita la URL completa de Neon y las credenciales del administrador; no muestra las contraseñas mientras las escribes y genera una clave JWT aleatoria.
3. Inicia el sistema: `npm start`.
4. Abre `http://localhost:3000`.

También puedes copiar `.env.example` como `.env` y completar manualmente todas las variables. `DATABASE_URL`, `JWT_SECRET`, `ADMIN_EMAIL` y `ADMIN_PASSWORD` son obligatorias. La clave JWT debe tener al menos 32 caracteres y la contraseña del administrador al menos 12.

## Publicación en GitHub y despliegue
1. Sube el código fuente, pero nunca el archivo `.env`, contraseñas, tokens ni credenciales.
2. Crea un servicio web conectado al repositorio (por ejemplo, Render).
3. Configura:
   - Build Command: `npm install`
   - Start Command: `npm start`
4. En las variables de entorno del proveedor configura `DATABASE_URL`, `DB_SSL=true`, `JWT_SECRET`, `ADMIN_EMAIL` y `ADMIN_PASSWORD`. Usa secretos nuevos y únicos; no reutilices los valores de ejemplo.
5. Comprueba la ruta `/salud` de tu aplicación desplegada.

## Seguridad
- `.env` está excluido de Git mediante `.gitignore`.
- El servidor no inicia si faltan variables obligatorias o si los secretos no cumplen los requisitos mínimos.
- El administrador se crea al iniciar si no existe. Si ya existe con el mismo correo configurado, su contraseña se sincroniza con `ADMIN_PASSWORD`.
- Si una contraseña o clave real se publicó anteriormente, cámbiala o rótala en el servicio correspondiente. Borrar el secreto del código no invalida una credencial ya expuesta.
